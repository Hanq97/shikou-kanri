'use strict';

/**
 * postinstall.js — Auto-setup when consumer runs `npm install eps-workflow`
 *
 * Steps:
 *   1. Detect consumer project root (INIT_CWD or cwd)
 *   2. Create .claude/ dirs if needed
 *   3. Create 4 symlinks: core, specialists, guards, skills
 *   4. Copy defaults to .claude/ (commands, rules, config) — skip-if-exists
 *
 * P4 fail-open: always exits with code 0 so that install never breaks for the consumer.
 */

const fs = require('fs');
const path = require('path');

// ── Helpers (inline to avoid requiring uninstalled dependencies) ──────────────

const { create: createSymlink } = require('./lib/symlink-manager');
const { copyDefaults } = require('./lib/defaults-copier');

// ── Resolve paths ─────────────────────────────────────────────────────────────

/**
 * Return the consumer project root.
 *
 * npm sets INIT_CWD to the directory where `npm install` was invoked.
 * `npm link` sets it as well. Fall back to process.cwd() for edge cases.
 */
function resolveConsumerRoot() {
  // INIT_CWD is the most reliable indicator for both `npm install` and `npm link`
  const initCwd = process.env.INIT_CWD;
  if (initCwd && fs.existsSync(initCwd)) {
    return initCwd;
  }
  // Fallback: walk up from cwd until we find a package.json that is NOT ours
  let dir = process.cwd();
  // If running from inside node_modules/eps-workflow, climb to project root
  const nmIdx = dir.lastIndexOf(`${path.sep}node_modules${path.sep}`);
  if (nmIdx !== -1) {
    return dir.slice(0, nmIdx);
  }
  return dir;
}

// The directory where THIS package is installed (eps-workflow package root)
const PKG_ROOT = __dirname;

// ── Main ──────────────────────────────────────────────────────────────────────

(function main() {
  let consumerRoot;
  try {
    consumerRoot = resolveConsumerRoot();
  } catch (e) {
    // Silently exit — P4 fail-open
    process.exit(0);
  }

  const claudeDir = path.join(consumerRoot, '.claude');

  // Step 1 — Ensure .claude/ base directory exists
  try {
    fs.mkdirSync(claudeDir, { recursive: true });
  } catch (e) {
    // Silently continue — P4 fail-open
    process.exit(0);
  }

  // Step 2 — Create 4 symlinks: core, specialists, guards, skills
  //   FROM: <consumerRoot>/.claude/<name>
  //   TO:   <PKG_ROOT>/<name>
  const SYMLINK_TARGETS = ['core', 'specialists', 'guards', 'skills'];

  for (const name of SYMLINK_TARGETS) {
    const target = path.join(PKG_ROOT, name);
    const link = path.join(claudeDir, name);

    try {
      const result = createSymlink(target, link);
      if (!result.ok) {
        // Non-fatal: log to stderr and continue
        process.stderr.write(
          `[eps-workflow] warn: could not link .claude/${name}: ${result.error || 'unknown'}\n`
        );
      }
    } catch (e) {
      process.stderr.write(`[eps-workflow] warn: could not link .claude/${name}: ${e.message}\n`);
    }
  }

  // Step 3 — Copy only commands + rules from defaults/ → .claude/ (skip-if-exists)
  // Config is NOT auto-copied — consumer uses `npx eps init` for config setup
  const defaultsSrc = path.join(PKG_ROOT, 'defaults');
  const COPY_DIRS = ['commands', 'rules'];

  for (const dir of COPY_DIRS) {
    const src = path.join(defaultsSrc, dir);
    const dest = path.join(claudeDir, dir);
    if (fs.existsSync(src)) {
      try {
        const result = copyDefaults(src, dest, { force: false });
        if (result.errors && result.errors.length > 0) {
          for (const err of result.errors) {
            process.stderr.write(`[eps-workflow] warn: copy default ${dir}: ${err}\n`);
          }
        }
      } catch (e) {
        process.stderr.write(`[eps-workflow] warn: copyDefaults ${dir} failed: ${e.message}\n`);
      }
    }
  }

  // Step 4 — Install git commit-msg hook (reject AI attribution)
  try {
    const gitHooksDir = path.join(consumerRoot, '.git', 'hooks');
    if (fs.existsSync(path.join(consumerRoot, '.git'))) {
      fs.mkdirSync(gitHooksDir, { recursive: true });
      const hookPath = path.join(gitHooksDir, 'commit-msg');
      if (!fs.existsSync(hookPath)) {
        const hookContent = `#!/bin/sh
# EPS Framework — Reject commits with AI attribution
# Rule: NEVER append AI attribution in commits (CLAUDE.md)

if grep -qiE "Co-Authored-By:.*Claude|Co-Authored-By:.*Anthropic|Co-Authored-By:.*noreply@anthropic" "$1"; then
  echo "❌ COMMIT REJECTED: AI attribution detected in commit message."
  echo "   Remove any 'Co-Authored-By: Claude' or 'Co-Authored-By: ...@anthropic.com' lines."
  echo "   Rule: CLAUDE.md — NEVER append AI attribution in commits."
  exit 1
fi
`;
        fs.writeFileSync(hookPath, hookContent, { mode: 0o755 });
      }
    }
  } catch (e) {
    process.stderr.write(`[eps-workflow] warn: could not install commit-msg hook: ${e.message}\n`);
  }

  // Done — always exit 0 (P4 fail-open)
  process.exit(0);
})();
